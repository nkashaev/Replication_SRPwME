// This file is a part of Julia. License is MIT: https://julialang.org/license

#ifndef JL_PTRHASH_H
#define JL_PTRHASH_H

#include "htable.h"

#ifdef __cplusplus
extern "C" {
#endif

HTPROT(ptrhash)

#ifdef __cplusplus
}
#endif

#endif
