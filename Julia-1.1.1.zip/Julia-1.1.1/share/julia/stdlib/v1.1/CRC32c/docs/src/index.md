# CRC32c

```@docs
CRC32c.crc32c
CRC32c.crc32c(::IO, ::Integer, ::UInt32)
```
